# 2024 © Idan Hazay config_s.py

# Global libraries
import os

# Global variables
SEP = "|"
LEN_FIELD = 4
CHUNK_SIZE = 524288

CLOUD_PATH = f"{os.getcwd()}\\cloud"
USER_ICONS_PATH = f"{os.getcwd()}\\user icons"